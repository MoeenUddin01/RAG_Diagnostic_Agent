# RAG Diagnostic Agent - Source Code

This package contains the source code for training the plant disease classification model on Kaggle.

## Contents

- `src/`: Source code modules
- `run.py`: Main training script
- `config.yaml`: Production configuration
- `config.dev.yaml`: Development configuration

## Usage on Kaggle

1. Extract this archive to `/kaggle/working/rag-diagnostic-agent/`
2. Follow the KAGGLE_GUIDE.md instructions for setup
3. Run training with: `python run.py config.yaml`
